from datetime import datetime

from pydantic import BaseModel, ConfigDict, EmailStr, Field, field_validator

from .models import Role


def _strong(p: str) -> str:
    if len(p) < 12:
        raise ValueError("password must be at least 12 characters")
    if not (any(c.isupper() for c in p) and any(c.islower() for c in p) and any(c.isdigit() for c in p)):
        raise ValueError("password needs upper case, lower case and a digit")
    return p


class TenantCreate(BaseModel):
    name: str = Field(min_length=2, max_length=200)


class TenantOut(BaseModel):
    model_config = ConfigDict(from_attributes=True)
    id: str
    name: str
    is_active: bool
    created_at: datetime


class UserCreate(BaseModel):
    email: EmailStr
    full_name: str = Field(min_length=2, max_length=200)
    password: str
    role: Role
    tenant_id: str | None = None  # only used by platform admin

    _check = field_validator("password")(_strong)


class UserOut(BaseModel):
    model_config = ConfigDict(from_attributes=True)
    id: str
    tenant_id: str | None
    email: EmailStr
    full_name: str
    role: Role
    is_active: bool
    mfa_enabled: bool


class LoginIn(BaseModel):
    email: EmailStr
    password: str
    otp: str | None = None


class TokenOut(BaseModel):
    access_token: str
    token_type: str = "bearer"


class MfaSetupOut(BaseModel):
    secret: str
    otpauth_uri: str


class MfaConfirmIn(BaseModel):
    code: str
