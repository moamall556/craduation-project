from contextlib import asynccontextmanager

from fastapi import FastAPI
from sqlalchemy import select

from .config import settings
from .database import Base, SessionLocal, engine
from .models import Role, User
from .routers import auth, tenants, users
from .security import hash_password


@asynccontextmanager
async def lifespan(app: FastAPI):
    Base.metadata.create_all(engine)
    with SessionLocal() as db:  # seed the first platform admin
        email = settings.bootstrap_admin_email.lower()
        if not db.scalar(select(User).where(User.email == email)):
            db.add(User(email=email, full_name="Platform Admin", role=Role.platform_admin,
                        password_hash=hash_password(settings.bootstrap_admin_password)))
            db.commit()
    yield


app = FastAPI(title="Secure Multi-Tenant Document Signing Framework", version="0.1.0", lifespan=lifespan)
app.include_router(auth.router)
app.include_router(tenants.router)
app.include_router(users.router)


@app.get("/health")
def health():
    return {"status": "ok"}
