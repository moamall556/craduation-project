from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy import select
from sqlalchemy.orm import Session

from ..database import get_db
from ..deps import current_user, require_roles
from ..models import Role, Tenant, User
from ..schemas import UserCreate, UserOut
from ..security import hash_password

router = APIRouter(prefix="/users", tags=["users"])


@router.get("/me", response_model=UserOut)
def me(user: User = Depends(current_user)):
    return user


@router.post("", response_model=UserOut, status_code=201)
def create_user(
    data: UserCreate,
    actor: User = Depends(require_roles(Role.platform_admin, Role.tenant_admin)),
    db: Session = Depends(get_db),
):
    if data.role == Role.platform_admin:
        raise HTTPException(403, "Cannot create platform admins via API")

    # Tenant isolation: a tenant admin can only ever create users in their own tenant.
    if actor.role == Role.tenant_admin:
        if data.tenant_id and data.tenant_id != actor.tenant_id:
            raise HTTPException(403, "Cannot create users in another tenant")
        tenant_id = actor.tenant_id
    else:
        if not data.tenant_id or not db.get(Tenant, data.tenant_id):
            raise HTTPException(400, "Valid tenant_id required")
        tenant_id = data.tenant_id

    email = data.email.lower()
    if db.scalar(select(User).where(User.email == email)):
        raise HTTPException(409, "Email already registered")
    u = User(tenant_id=tenant_id, email=email, full_name=data.full_name,
             password_hash=hash_password(data.password), role=data.role)
    db.add(u)
    db.commit()
    return u


@router.get("", response_model=list[UserOut])
def list_users(
    actor: User = Depends(require_roles(Role.tenant_admin, Role.auditor)),
    db: Session = Depends(get_db),
):
    return db.scalars(select(User).where(User.tenant_id == actor.tenant_id)).all()


@router.get("/{user_id}", response_model=UserOut)
def get_user(
    user_id: str,
    actor: User = Depends(require_roles(Role.tenant_admin, Role.auditor)),
    db: Session = Depends(get_db),
):
    u = db.scalar(select(User).where(User.id == user_id, User.tenant_id == actor.tenant_id))
    if not u:  # 404 (not 403) so other tenants' IDs are not even revealed
        raise HTTPException(404, "User not found")
    return u


@router.post("/{user_id}/deactivate", response_model=UserOut)
def deactivate_user(
    user_id: str,
    actor: User = Depends(require_roles(Role.tenant_admin)),
    db: Session = Depends(get_db),
):
    u = db.scalar(select(User).where(User.id == user_id, User.tenant_id == actor.tenant_id))
    if not u:
        raise HTTPException(404, "User not found")
    u.is_active = False
    db.commit()
    return u
