from datetime import timedelta, timezone

from fastapi import APIRouter, Depends, HTTPException, status
from sqlalchemy import select
from sqlalchemy.orm import Session

from ..config import settings
from ..database import get_db
from ..deps import current_user
from ..models import Tenant, User, now
from ..schemas import LoginIn, MfaConfirmIn, MfaSetupOut, TokenOut
from ..security import create_token, mfa_uri, new_mfa_secret, verify_otp, verify_password

router = APIRouter(prefix="/auth", tags=["auth"])
BAD = HTTPException(status.HTTP_401_UNAUTHORIZED, "Invalid credentials")


@router.post("/login", response_model=TokenOut)
def login(data: LoginIn, db: Session = Depends(get_db)):
    user = db.scalar(select(User).where(User.email == data.email.lower()))
    locked = user.locked_until if user else None
    if locked is not None and locked.tzinfo is None:
        locked = locked.replace(tzinfo=timezone.utc)
    if locked is not None and locked > now():
        raise HTTPException(status.HTTP_423_LOCKED, "Account temporarily locked")

    ok = verify_password(data.password, user.password_hash if user else None)
    if not user or not ok or not user.is_active:
        if user:
            user.failed_attempts += 1
            if user.failed_attempts >= settings.max_failed_logins:
                user.locked_until = now() + timedelta(minutes=settings.lockout_minutes)
                user.failed_attempts = 0
            db.commit()
        raise BAD

    if user.tenant_id:
        tenant = db.get(Tenant, user.tenant_id)
        if not tenant or not tenant.is_active:
            raise BAD

    if user.mfa_enabled:
        if not data.otp:
            raise HTTPException(status.HTTP_401_UNAUTHORIZED, "MFA code required")
        if not verify_otp(user.mfa_secret, data.otp):
            user.failed_attempts += 1
            db.commit()
            raise BAD

    user.failed_attempts = 0
    user.locked_until = None
    db.commit()
    return TokenOut(access_token=create_token(user.id, user.tenant_id, user.role.value))


@router.post("/mfa/setup", response_model=MfaSetupOut)
def mfa_setup(user: User = Depends(current_user), db: Session = Depends(get_db)):
    if user.mfa_enabled:
        raise HTTPException(400, "MFA already enabled")
    user.mfa_secret = new_mfa_secret()
    db.commit()
    return MfaSetupOut(secret=user.mfa_secret, otpauth_uri=mfa_uri(user.mfa_secret, user.email))


@router.post("/mfa/confirm")
def mfa_confirm(data: MfaConfirmIn, user: User = Depends(current_user), db: Session = Depends(get_db)):
    if not user.mfa_secret or not verify_otp(user.mfa_secret, data.code):
        raise HTTPException(400, "Invalid code")
    user.mfa_enabled = True
    db.commit()
    return {"mfa_enabled": True}
