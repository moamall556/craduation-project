from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy import select
from sqlalchemy.orm import Session

from ..database import get_db
from ..deps import require_roles
from ..models import Role, Tenant
from ..schemas import TenantCreate, TenantOut

router = APIRouter(prefix="/tenants", tags=["tenants"],
                   dependencies=[Depends(require_roles(Role.platform_admin))])


@router.post("", response_model=TenantOut, status_code=201)
def create_tenant(data: TenantCreate, db: Session = Depends(get_db)):
    if db.scalar(select(Tenant).where(Tenant.name == data.name)):
        raise HTTPException(409, "Tenant name already exists")
    t = Tenant(name=data.name)
    db.add(t)
    db.commit()
    return t


@router.get("", response_model=list[TenantOut])
def list_tenants(db: Session = Depends(get_db)):
    return db.scalars(select(Tenant).order_by(Tenant.created_at)).all()


@router.post("/{tenant_id}/deactivate", response_model=TenantOut)
def deactivate(tenant_id: str, db: Session = Depends(get_db)):
    t = db.get(Tenant, tenant_id)
    if not t:
        raise HTTPException(404, "Tenant not found")
    t.is_active = False
    db.commit()
    return t
