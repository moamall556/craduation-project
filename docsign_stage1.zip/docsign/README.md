# Secure Multi-Tenant Document Signing Framework (Stage 1)

Stage 1 covers: tenants, login (Argon2), TOTP MFA, account lockout, RBAC, tenant isolation.

## Run locally (no Docker)
    pip install -r requirements.txt
    uvicorn app.main:app --reload
Open http://localhost:8000/docs for the interactive API.

## Run with Docker + PostgreSQL
    cp .env.example .env     # edit the secrets
    docker compose up --build

## Tests
    python -m pytest -v

## Try it
1. POST /auth/login with the bootstrap admin (platform_admin).
2. POST /tenants, then POST /users with role tenant_admin and that tenant_id.
3. Log in as the tenant admin and create signer / requester / auditor users.
4. POST /auth/mfa/setup then /auth/mfa/confirm to enable MFA (scan the otpauth URI in an authenticator app).

## Roles
platform_admin, tenant_admin, signer, requester, auditor
