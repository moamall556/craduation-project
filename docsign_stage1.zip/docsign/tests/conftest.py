import os, tempfile

_tmp = tempfile.mkdtemp()
os.environ["DATABASE_URL"] = f"sqlite:///{_tmp}/test.db"
os.environ["BOOTSTRAP_ADMIN_EMAIL"] = "root@example.com"
os.environ["BOOTSTRAP_ADMIN_PASSWORD"] = "RootPassword-12345"

import pytest
from fastapi.testclient import TestClient
from app.main import app


@pytest.fixture(scope="session")
def client():
    with TestClient(app) as c:
        yield c


def login(client, email, password, otp=None):
    r = client.post("/auth/login", json={"email": email, "password": password, "otp": otp})
    return r


def auth(token):
    return {"Authorization": f"Bearer {token}"}
