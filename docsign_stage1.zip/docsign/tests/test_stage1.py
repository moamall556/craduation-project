import pyotp
from .conftest import auth, login

PW = "StrongPassw0rd!!"


def token(client, email, pw=PW, otp=None):
    r = login(client, email, pw, otp)
    assert r.status_code == 200, r.text
    return r.json()["access_token"]


def setup_tenants(client):
    root = token(client, "root@example.com", "RootPassword-12345")
    ids = {}
    for name in ("Ministry A", "Ministry B"):
        t = client.post("/tenants", json={"name": name}, headers=auth(root)).json()
        ids[name] = t["id"]
        slug = name[-1].lower()
        r = client.post("/users", headers=auth(root), json={
            "email": f"admin{slug}@example.com", "full_name": f"Admin {slug}",
            "password": PW, "role": "tenant_admin", "tenant_id": t["id"]})
        assert r.status_code == 201, r.text
    return root, ids


def test_tenant_isolation(client):
    root, ids = setup_tenants(client)
    a = token(client, "admina@example.com")
    b = token(client, "adminb@example.com")

    r = client.post("/users", headers=auth(a), json={
        "email": "signer1@example.com", "full_name": "Signer One", "password": PW, "role": "signer"})
    assert r.status_code == 201
    signer_id = r.json()["id"]
    assert r.json()["tenant_id"] == ids["Ministry A"]

    # tenant B cannot see tenant A's user: 404, and the list does not leak
    assert client.get(f"/users/{signer_id}", headers=auth(b)).status_code == 404
    assert signer_id not in [u["id"] for u in client.get("/users", headers=auth(b)).json()]
    # tenant A can
    assert client.get(f"/users/{signer_id}", headers=auth(a)).status_code == 200
    # tenant B cannot deactivate A's user nor create users inside A
    assert client.post(f"/users/{signer_id}/deactivate", headers=auth(b)).status_code == 404
    r = client.post("/users", headers=auth(b), json={
        "email": "evil@example.com", "full_name": "Evil", "password": PW,
        "role": "signer", "tenant_id": ids["Ministry A"]})
    assert r.status_code == 403


def test_role_enforcement(client):
    setup = token(client, "admina@example.com")
    signer = token(client, "signer1@example.com")
    assert client.post("/tenants", json={"name": "X Corp"}, headers=auth(setup)).status_code == 403
    assert client.get("/users", headers=auth(signer)).status_code == 403
    assert client.post("/users", headers=auth(signer), json={
        "email": "z@example.com", "full_name": "Zed Zed", "password": PW, "role": "signer"}).status_code == 403
    assert client.get("/users/me").status_code == 401


def test_weak_password_and_platform_admin_creation(client):
    a = token(client, "admina@example.com")
    r = client.post("/users", headers=auth(a), json={
        "email": "weak@example.com", "full_name": "Weak One", "password": "short", "role": "signer"})
    assert r.status_code == 422
    r = client.post("/users", headers=auth(a), json={
        "email": "pa@example.com", "full_name": "Pa Pa", "password": PW, "role": "platform_admin"})
    assert r.status_code == 403


def test_mfa_flow(client):
    t = token(client, "signer1@example.com")
    secret = client.post("/auth/mfa/setup", headers=auth(t)).json()["secret"]
    assert client.post("/auth/mfa/confirm", json={"code": "000000"}, headers=auth(t)).status_code == 400
    code = pyotp.TOTP(secret).now()
    assert client.post("/auth/mfa/confirm", json={"code": code}, headers=auth(t)).status_code == 200
    # now login requires the OTP
    assert login(client, "signer1@example.com", PW).status_code == 401
    assert login(client, "signer1@example.com", PW, "111111").status_code == 401
    assert login(client, "signer1@example.com", PW, pyotp.TOTP(secret).now()).status_code == 200


def test_lockout(client):
    root = token(client, "root@example.com", "RootPassword-12345")
    ids = client.get("/tenants", headers=auth(root)).json()
    a = token(client, "admina@example.com")
    client.post("/users", headers=auth(a), json={
        "email": "victim@example.com", "full_name": "Vic Tim", "password": PW, "role": "requester"})
    for _ in range(5):
        assert login(client, "victim@example.com", "wrong-password").status_code == 401
    assert login(client, "victim@example.com", PW).status_code == 423


def test_deactivated_tenant_blocks_users(client):
    root = token(client, "root@example.com", "RootPassword-12345")
    b = token(client, "adminb@example.com")
    tid = [t for t in client.get("/tenants", headers=auth(root)).json() if t["name"] == "Ministry B"][0]["id"]
    client.post(f"/tenants/{tid}/deactivate", headers=auth(root))
    assert client.get("/users/me", headers=auth(b)).status_code == 401
    assert login(client, "adminb@example.com", PW).status_code == 401
