"""Internal Certificate Authority: Root CA -> Issuing CA -> user certificates.

Private keys are encrypted with AES-256-GCM using a key derived (scrypt) from MASTER_KEY.
In a real deployment the root key would live offline / in an HSM.
"""
import base64
import hashlib
import os
from datetime import datetime, timedelta, timezone
from functools import lru_cache

from cryptography import x509
from cryptography.hazmat.primitives import hashes, serialization
from cryptography.hazmat.primitives.asymmetric import rsa
from cryptography.hazmat.primitives.ciphers.aead import AESGCM
from cryptography.x509.oid import ExtendedKeyUsageOID, NameOID, ObjectIdentifier
from sqlalchemy import select
from sqlalchemy.orm import Session

from .config import settings
from .models import CaAuthority, CertStatus, Certificate, Tenant, User, new_id, now

DOC_SIGNING_EKU = ObjectIdentifier("1.3.6.1.5.5.7.3.36")  # id-kp-documentSigning (RFC 9336)
REASONS = {
    "unspecified": x509.ReasonFlags.unspecified,
    "key_compromise": x509.ReasonFlags.key_compromise,
    "affiliation_changed": x509.ReasonFlags.affiliation_changed,
    "superseded": x509.ReasonFlags.superseded,
    "cessation_of_operation": x509.ReasonFlags.cessation_of_operation,
}


# ---------- private-key protection ----------
@lru_cache(maxsize=1)
def _aes_key() -> bytes:
    return hashlib.scrypt(settings.master_key.encode(), salt=b"docsign-key-wrap-v1", n=2**14, r=8, p=1, dklen=32)


def encrypt_bytes(data: bytes, aad: bytes) -> str:
    nonce = os.urandom(12)
    return base64.b64encode(nonce + AESGCM(_aes_key()).encrypt(nonce, data, aad)).decode()


def decrypt_bytes(token: str, aad: bytes) -> bytes:
    raw = base64.b64decode(token)
    return AESGCM(_aes_key()).decrypt(raw[:12], raw[12:], aad)  # raises InvalidTag if tampered


def _key_to_pem(key) -> bytes:
    return key.private_bytes(serialization.Encoding.PEM, serialization.PrivateFormat.PKCS8,
                             serialization.NoEncryption())


def aware(dt: datetime) -> datetime:
    return dt if dt.tzinfo else dt.replace(tzinfo=timezone.utc)


def _trim(s: str, n: int = 64) -> str:
    return s.strip()[:n]


# ---------- CA hierarchy ----------
def _create_ca(cn: str, issuer_cert=None, issuer_key=None, years=10, path_length=1):
    key = rsa.generate_private_key(public_exponent=65537, key_size=3072)
    name = x509.Name([x509.NameAttribute(NameOID.ORGANIZATION_NAME, "DocSign Internal PKI"),
                      x509.NameAttribute(NameOID.COMMON_NAME, cn)])
    t = now()
    builder = (
        x509.CertificateBuilder()
        .subject_name(name)
        .issuer_name(issuer_cert.subject if issuer_cert else name)
        .public_key(key.public_key())
        .serial_number(x509.random_serial_number())
        .not_valid_before(t - timedelta(minutes=5))
        .not_valid_after(t + timedelta(days=365 * years))
        .add_extension(x509.BasicConstraints(ca=True, path_length=path_length), critical=True)
        .add_extension(x509.KeyUsage(digital_signature=False, content_commitment=False, key_encipherment=False,
                                     data_encipherment=False, key_agreement=False, key_cert_sign=True,
                                     crl_sign=True, encipher_only=False, decipher_only=False), critical=True)
        .add_extension(x509.SubjectKeyIdentifier.from_public_key(key.public_key()), critical=False)
    )
    if issuer_cert:
        builder = builder.add_extension(
            x509.AuthorityKeyIdentifier.from_issuer_public_key(issuer_cert.public_key()), critical=False)
    cert = builder.sign(issuer_key or key, hashes.SHA256())
    return cert, key


def ensure_ca(db: Session) -> None:
    """Create the root and issuing CA on first start."""
    if db.get(CaAuthority, "root") and db.get(CaAuthority, "issuing"):
        return
    root_cert, root_key = _create_ca("DocSign Root CA", years=10, path_length=1)
    iss_cert, iss_key = _create_ca("DocSign Issuing CA", root_cert, root_key, years=5, path_length=0)
    for name, cert, key in (("root", root_cert, root_key), ("issuing", iss_cert, iss_key)):
        db.merge(CaAuthority(name=name, cert_pem=cert.public_bytes(serialization.Encoding.PEM).decode(),
                             enc_private_key=encrypt_bytes(_key_to_pem(key), f"ca:{name}".encode())))
    db.commit()


def load_ca(db: Session, name: str):
    row = db.get(CaAuthority, name)
    cert = x509.load_pem_x509_certificate(row.cert_pem.encode())
    key = serialization.load_pem_private_key(decrypt_bytes(row.enc_private_key, f"ca:{name}".encode()), None)
    return cert, key


def chain_pem(db: Session) -> str:
    return db.get(CaAuthority, "issuing").cert_pem + db.get(CaAuthority, "root").cert_pem


# ---------- user certificates ----------
def issue_user_certificate(db: Session, user: User, tenant: Tenant) -> Certificate:
    iss_cert, iss_key = load_ca(db, "issuing")
    key = rsa.generate_private_key(public_exponent=65537, key_size=2048)
    subject = x509.Name([
        x509.NameAttribute(NameOID.ORGANIZATION_NAME, _trim(tenant.name)),
        x509.NameAttribute(NameOID.COMMON_NAME, _trim(user.full_name)),
        x509.NameAttribute(NameOID.EMAIL_ADDRESS, _trim(user.email, 128)),
    ])
    t = now()
    cert = (
        x509.CertificateBuilder()
        .subject_name(subject)
        .issuer_name(iss_cert.subject)
        .public_key(key.public_key())
        .serial_number(x509.random_serial_number())
        .not_valid_before(t - timedelta(minutes=5))
        .not_valid_after(t + timedelta(days=settings.cert_valid_days))
        .add_extension(x509.BasicConstraints(ca=False, path_length=None), critical=True)
        .add_extension(x509.KeyUsage(digital_signature=True, content_commitment=True, key_encipherment=False,
                                     data_encipherment=False, key_agreement=False, key_cert_sign=False,
                                     crl_sign=False, encipher_only=False, decipher_only=False), critical=True)
        .add_extension(x509.ExtendedKeyUsage([DOC_SIGNING_EKU, ExtendedKeyUsageOID.EMAIL_PROTECTION]), critical=False)
        .add_extension(x509.SubjectAlternativeName([x509.RFC822Name(user.email)]), critical=False)
        .add_extension(x509.SubjectKeyIdentifier.from_public_key(key.public_key()), critical=False)
        .add_extension(x509.AuthorityKeyIdentifier.from_issuer_public_key(iss_cert.public_key()), critical=False)
        .add_extension(x509.CRLDistributionPoints([x509.DistributionPoint(
            full_name=[x509.UniformResourceIdentifier(f"{settings.public_base_url}/ca/crl.pem")],
            relative_name=None, reasons=None, crl_issuer=None)]), critical=False)
        .sign(iss_key, hashes.SHA256())
    )
    cert_id = new_id()  # bound into the encryption as associated data
    c = Certificate(
        id=cert_id, tenant_id=tenant.id, user_id=user.id, serial=format(cert.serial_number, "x"),
        subject=cert.subject.rfc4514_string(),
        cert_pem=cert.public_bytes(serialization.Encoding.PEM).decode(),
        enc_private_key=encrypt_bytes(_key_to_pem(key), f"cert:{cert_id}".encode()),
        not_before=cert.not_valid_before_utc, not_after=cert.not_valid_after_utc,
    )
    db.add(c)
    db.commit()
    return c


def load_user_private_key(c: Certificate):
    """Internal use only (signing service). Never exposed through the API."""
    return serialization.load_pem_private_key(decrypt_bytes(c.enc_private_key, f"cert:{c.id}".encode()), None)


def revoke_certificate(db: Session, c: Certificate, reason: str = "unspecified") -> None:
    if c.status == CertStatus.revoked:
        return
    c.status = CertStatus.revoked
    c.revoked_at = now()
    c.revocation_reason = reason if reason in REASONS else "unspecified"
    db.commit()


def revoke_user_certificates(db: Session, user_id: str, reason: str) -> None:
    for c in db.scalars(select(Certificate).where(Certificate.user_id == user_id,
                                                  Certificate.status == CertStatus.active)):
        revoke_certificate(db, c, reason)


def build_crl(db: Session) -> bytes:
    iss_cert, iss_key = load_ca(db, "issuing")
    t = now()
    b = (x509.CertificateRevocationListBuilder().issuer_name(iss_cert.subject)
         .last_update(t).next_update(t + timedelta(days=7)))
    for c in db.scalars(select(Certificate).where(Certificate.status == CertStatus.revoked)):
        b = b.add_revoked_certificate(
            x509.RevokedCertificateBuilder().serial_number(int(c.serial, 16))
            .revocation_date(aware(c.revoked_at))
            .add_extension(x509.CRLReason(REASONS[c.revocation_reason or "unspecified"]), critical=False).build())
    b = b.add_extension(x509.CRLNumber(int(t.timestamp())), critical=False)
    return b.sign(iss_key, hashes.SHA256()).public_bytes(serialization.Encoding.PEM)


def certificate_state(db: Session, c: Certificate) -> str:
    """valid | revoked | expired | untrusted  (used later by the verification service)."""
    cert = x509.load_pem_x509_certificate(c.cert_pem.encode())
    iss, _ = load_ca(db, "issuing")
    root = x509.load_pem_x509_certificate(db.get(CaAuthority, "root").cert_pem.encode())
    try:
        cert.verify_directly_issued_by(iss)
        iss.verify_directly_issued_by(root)
    except Exception:
        return "untrusted"
    if c.status == CertStatus.revoked:
        return "revoked"
    if aware(c.not_after) < now():
        return "expired"
    return "valid"
