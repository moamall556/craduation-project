import enum
import uuid
from datetime import datetime, timezone

from sqlalchemy import Boolean, DateTime, Enum, ForeignKey, Integer, String, Text
from sqlalchemy.orm import Mapped, mapped_column

from .database import Base


def now() -> datetime:
    return datetime.now(timezone.utc)


def new_id() -> str:
    return str(uuid.uuid4())


class Role(str, enum.Enum):
    platform_admin = "platform_admin"  # manages tenants, belongs to no tenant
    tenant_admin = "tenant_admin"      # manages users of one tenant
    signer = "signer"                  # may sign documents
    requester = "requester"            # may upload documents / request signatures
    auditor = "auditor"                # read-only access to audit trail


class Tenant(Base):
    __tablename__ = "tenants"
    id: Mapped[str] = mapped_column(String(36), primary_key=True, default=new_id)
    name: Mapped[str] = mapped_column(String(200), unique=True)
    is_active: Mapped[bool] = mapped_column(Boolean, default=True)
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=now)


class User(Base):
    __tablename__ = "users"
    id: Mapped[str] = mapped_column(String(36), primary_key=True, default=new_id)
    tenant_id: Mapped[str | None] = mapped_column(ForeignKey("tenants.id"), nullable=True, index=True)
    email: Mapped[str] = mapped_column(String(320), unique=True, index=True)
    full_name: Mapped[str] = mapped_column(String(200))
    password_hash: Mapped[str] = mapped_column(String(255))
    role: Mapped[Role] = mapped_column(Enum(Role))
    is_active: Mapped[bool] = mapped_column(Boolean, default=True)
    mfa_secret: Mapped[str | None] = mapped_column(String(64), nullable=True)
    mfa_enabled: Mapped[bool] = mapped_column(Boolean, default=False)
    failed_attempts: Mapped[int] = mapped_column(Integer, default=0)
    locked_until: Mapped[datetime | None] = mapped_column(DateTime(timezone=True), nullable=True)
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=now)


class CertStatus(str, enum.Enum):
    active = "active"
    revoked = "revoked"


class CaAuthority(Base):
    """Internal CA hierarchy: one 'root' row and one 'issuing' row."""
    __tablename__ = "ca_authorities"
    name: Mapped[str] = mapped_column(String(20), primary_key=True)
    cert_pem: Mapped[str] = mapped_column(Text)
    enc_private_key: Mapped[str] = mapped_column(Text)  # AES-256-GCM, base64


class Certificate(Base):
    __tablename__ = "certificates"
    id: Mapped[str] = mapped_column(String(36), primary_key=True, default=new_id)
    tenant_id: Mapped[str] = mapped_column(ForeignKey("tenants.id"), index=True)
    user_id: Mapped[str] = mapped_column(ForeignKey("users.id"), index=True)
    serial: Mapped[str] = mapped_column(String(64), unique=True)  # hex
    subject: Mapped[str] = mapped_column(String(500))
    cert_pem: Mapped[str] = mapped_column(Text)
    enc_private_key: Mapped[str] = mapped_column(Text)  # never leaves the server
    not_before: Mapped[datetime] = mapped_column(DateTime(timezone=True))
    not_after: Mapped[datetime] = mapped_column(DateTime(timezone=True))
    status: Mapped[CertStatus] = mapped_column(Enum(CertStatus), default=CertStatus.active)
    revoked_at: Mapped[datetime | None] = mapped_column(DateTime(timezone=True), nullable=True)
    revocation_reason: Mapped[str | None] = mapped_column(String(40), nullable=True)
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=now)
