(() => {
"use strict";
const SEAL = (s) => `<svg width="${s}" height="${s}" viewBox="0 0 48 48" fill="none" aria-hidden="true"><circle cx="24" cy="24" r="22" stroke="#52C7BF" stroke-width="2"/><circle cx="24" cy="24" r="17" stroke="#52C7BF" stroke-width="1" stroke-dasharray="2 3"/><path d="M15 25l7 7 12-14" stroke="#fff" stroke-width="3.5" stroke-linecap="round" stroke-linejoin="round"/></svg>`;

const S = { lang: localStorage.getItem("lang") || "en", token: sessionStorage.getItem("tok"), me: null, view: null, needOtp: false, loginErr: "" };
const $app = document.getElementById("app");

// ---------- helpers ----------
function t(k, vars) { const d = I18N[S.lang]; let s = d[k] ?? I18N.en[k] ?? k; return s; }
function h(tag, attrs, ...kids) {
  const el = document.createElement(tag);
  for (const [k, v] of Object.entries(attrs || {})) {
    if (v == null || v === false) continue;
    if (k === "class") el.className = v;
    else if (k.startsWith("on")) el.addEventListener(k.slice(2), v);
    else if (v === true) el.setAttribute(k, "");
    else el.setAttribute(k, v);
  }
  for (const c of kids.flat()) if (c != null && c !== false) el.append(c.nodeType ? c : document.createTextNode(String(c)));
  return el;
}
const svgIcon = (size) => { const d = document.createElement("span"); d.innerHTML = SEAL(size); return d.firstChild; };
const locale = () => (S.lang === "ar" ? "ar-u-nu-latn" : "en-GB");
const fmtDate = (x) => new Date(x).toLocaleDateString(locale(), { year: "numeric", month: "short", day: "numeric" });
function toast(msg, isErr) {
  const box = document.getElementById("toast"); box.replaceChildren(h("div", { class: isErr ? "err" : "" }, msg));
  clearTimeout(toast.t); toast.t = setTimeout(() => box.replaceChildren(), 3500);
}
function errText(detail) {
  if (Array.isArray(detail)) return detail.map((d) => d.msg).join("; ");
  const map = I18N[S.lang].errs || {};
  return map[detail] || detail || t("err_generic");
}
async function api(path, opts = {}) {
  const headers = { ...(opts.json ? { "Content-Type": "application/json" } : {}) };
  if (S.token) headers.Authorization = "Bearer " + S.token;
  const res = await fetch(path, { method: opts.method || "GET", headers, body: opts.json ? JSON.stringify(opts.json) : undefined });
  let body = null; try { body = await res.json(); } catch (_) {}
  if (!res.ok) {
    if (res.status === 401 && S.token && path !== "/auth/login") { logout(t("err_session")); }
    const e = new Error(errText(body && body.detail)); e.status = res.status; e.detail = body && body.detail; throw e;
  }
  return body;
}
function logout(msg) { S.token = null; S.me = null; S.needOtp = false; S.loginErr = msg || ""; sessionStorage.removeItem("tok"); render(); }
function setLang(l) { S.lang = l; localStorage.setItem("lang", l); render(); }
function applyLang() { document.documentElement.lang = S.lang; document.documentElement.dir = S.lang === "ar" ? "rtl" : "ltr"; document.title = "DocSign"; }
const langBtn = () => h("button", { class: "lang", type: "button", onclick: () => setLang(S.lang === "ar" ? "en" : "ar") }, t("language"));
const badge = (cls, text) => h("span", { class: "stamp " + cls }, text);

function field(label, input, hint) {
  const id = "f" + Math.random().toString(36).slice(2, 8); input.id = id;
  return h("div", { class: "field" }, h("label", { for: id }, label), input, hint ? h("span", { class: "hint" }, hint) : null);
}
function modal(title, body, actions) {
  const close = () => ov.remove();
  const ov = h("div", { class: "overlay", onclick: (e) => e.target === ov && close() },
    h("div", { class: "modal", role: "dialog", "aria-modal": "true", "aria-label": title },
      h("h2", {}, title), body, h("div", { class: "form-actions" }, ...(actions ? actions(close) : [h("button", { class: "btn", onclick: close }, t("close"))]))));
  document.body.append(ov); const f = ov.querySelector("input,select,button"); f && f.focus(); return close;
}
async function guarded(fn) { try { await fn(); } catch (e) { toast(e.message || t("err_generic"), true); } }

// ---------- login ----------
function renderLogin() {
  const email = h("input", { type: "email", class: "ltr", autocomplete: "username", required: true });
  const pw = h("input", { type: "password", class: "ltr", autocomplete: "current-password", required: true });
  const otp = h("input", { type: "text", class: "ltr", inputmode: "numeric", autocomplete: "one-time-code", maxlength: "6" });
  const err = h("div", { class: "alert", role: "alert", hidden: !S.loginErr }, S.loginErr);
  const form = h("form", { onsubmit: async (e) => {
      e.preventDefault(); err.hidden = true;
      try {
        const r = await api("/auth/login", { method: "POST", json: { email: email.value.trim(), password: pw.value, otp: otp.value.trim() || null } });
        S.token = r.access_token; sessionStorage.setItem("tok", S.token); S.needOtp = false; S.loginErr = ""; await boot();
      } catch (ex) {
        if (ex.detail === "MFA code required") { S.needOtp = true; S.pending = { e: email.value, p: pw.value }; render(); return; }
        err.textContent = ex.message; err.hidden = false;
      }
    } },
    err, field(t("email"), email), field(t("password"), pw),
    S.needOtp ? field(t("otp"), otp, t("otp_hint")) : null,
    h("button", { class: "btn primary", type: "submit" }, t("signin")));
  if (S.needOtp && S.pending) { email.value = S.pending.e; pw.value = S.pending.p; setTimeout(() => otp.focus(), 0); }
  const wm = h("div", { class: "watermark" }); wm.innerHTML = SEAL(420);
  $app.replaceChildren(h("div", { class: "login" },
    h("aside", { class: "login-panel on-ink" }, wm,
      h("div", { class: "brand" }, svgIcon(36), h("div", {}, "DocSign", h("small", {}, t("brand_sub")))),
      h("div", { class: "tagline" }, t("tagline")),
      h("ul", { class: "login-points" }, h("li", {}, t("pt1")), h("li", {}, t("pt2")), h("li", {}, t("pt3")))),
    h("main", { class: "login-main" }, h("div", { class: "login-top" }, langBtn()),
      h("div", { class: "login-form" }, h("h1", {}, t("login_title")), h("p", { class: "muted" }, t("login_sub")), form))));
}

// ---------- shell ----------
function navItems() {
  const r = S.me.role;
  if (r === "platform_admin") return ["tenants"];
  const items = [];
  if (r === "tenant_admin" || r === "auditor") items.push("users", "certs");
  if (r === "signer") items.push("mycert");
  items.push("security");
  return items;
}
async function renderShell() {
  if (!navItems().includes(S.view)) S.view = navItems()[0];
  const main = h("main", { class: "main" });
  const nav = h("nav", { class: "nav", "aria-label": "Main" }, navItems().map((v) =>
    h("button", { type: "button", "aria-current": v === S.view ? "page" : null, onclick: () => { S.view = v; renderShell(); } }, t("nav_" + v))));
  main.append(
    h("div", { class: "topbar" }, h("div", { class: "who" }, h("div", {}, h("div", { class: "name" }, S.me.full_name), h("div", { class: "role" }, t("role_" + S.me.role)))),
      h("div", { class: "tools" }, langBtn(), h("button", { class: "btn", type: "button", onclick: () => logout() }, t("signout")))),
    h("div", { class: "empty" }, t("loading")));
  $app.replaceChildren(h("div", { class: "shell" },
    h("aside", { class: "side on-ink" }, h("div", { class: "brand" }, svgIcon(32), h("div", {}, "DocSign")), nav,
      h("div", { class: "side-foot" }, S.me.email)), main));
  const body = h("div", {});
  try { body.append(await VIEWS[S.view]()); } catch (e) { body.append(h("div", { class: "alert" }, e.message)); }
  main.lastChild.replaceWith(body);
}
function pageHead(title, sub, right) {
  return h("div", { class: "page-head" }, h("div", {}, h("h1", {}, title), sub ? h("p", { class: "muted" }, sub) : null), right || null);
}
const reload = () => renderShell();

// ---------- views ----------
const ROLES_NEW = ["signer", "requester", "auditor", "tenant_admin"];
const certState = (c) => (c.status === "revoked" ? "revoked" : new Date(c.not_after) < new Date() ? "expired" : "active");
const certBadge = (c) => { const s = certState(c); return badge(s === "active" ? "ok" : s === "revoked" ? "bad" : "warn", t("c_" + s)); };
const cn = (subject) => { const m = /CN=((?:\\.|[^,])+)/.exec(subject); return m ? m[1].replace(/\\(.)/g, "$1") : subject; };

function userForm(extra, onDone) {
  const name = h("input", { type: "text", required: true, minlength: "2" });
  const mail = h("input", { type: "email", class: "ltr", required: true });
  const pw = h("input", { type: "password", class: "ltr", required: true, minlength: "12", autocomplete: "new-password" });
  const role = extra.fixedRole ? null : h("select", {}, ROLES_NEW.map((r) => h("option", { value: r }, t("role_" + r))));
  return h("form", { class: "panel", onsubmit: (e) => { e.preventDefault(); guarded(async () => {
      await api("/users", { method: "POST", json: { full_name: name.value.trim(), email: mail.value.trim(), password: pw.value,
        role: extra.fixedRole || role.value, ...(extra.tenantSelect ? { tenant_id: extra.tenantSelect.value } : {}) } });
      toast(t("done")); onDone(); }); } },
    h("h2", {}, extra.title),
    h("div", { class: "form-grid" }, extra.tenantSelect ? field(t("org"), extra.tenantSelect) : null,
      field(t("full_name"), name), field(t("email"), mail), field(t("password"), pw, t("pw_rule")), role ? field(t("role"), role) : null),
    h("div", { class: "form-actions" }, h("button", { class: "btn primary", type: "submit" }, t("create"))));
}

const VIEWS = {
  async tenants() {
    const list = await api("/tenants");
    const nameIn = h("input", { type: "text", required: true, minlength: "2" });
    const sel = h("select", {}, list.filter((x) => x.is_active).map((x) => h("option", { value: x.id }, x.name)));
    const rows = list.map((x) => h("tr", {}, h("td", { class: "strong" }, x.name), h("td", {}, fmtDate(x.created_at)),
      h("td", {}, badge(x.is_active ? "ok" : "off", x.is_active ? t("u_active") : t("u_inactive"))),
      h("td", {}, x.is_active ? h("button", { class: "btn small danger", onclick: () => confirm(t("confirm_deactivate_org")) && guarded(async () => { await api(`/tenants/${x.id}/deactivate`, { method: "POST" }); reload(); }) }, t("deactivate")) : null)));
    return h("div", {}, pageHead(t("tenants_title"), t("tenants_sub")),
      h("form", { class: "panel", onsubmit: (e) => { e.preventDefault(); guarded(async () => { await api("/tenants", { method: "POST", json: { name: nameIn.value.trim() } }); toast(t("done")); reload(); }); } },
        h("h2", {}, t("add_org")), h("div", { class: "form-grid" }, field(t("org_name"), nameIn)),
        h("div", { class: "form-actions" }, h("button", { class: "btn primary", type: "submit" }, t("create")))),
      table([t("name"), t("created"), t("status"), t("actions")], rows),
      sel.options.length ? h("div", { style: "margin-top:22px" }, userForm({ title: t("org_admin_title"), fixedRole: "tenant_admin", tenantSelect: sel }, reload)) : null);
  },

  async users() {
    const [users, certs] = await Promise.all([api("/users"), api("/certificates")]);
    const isAdmin = S.me.role === "tenant_admin";
    const activeCert = (uid) => certs.find((c) => c.user_id === uid && certState(c) === "active");
    const rows = users.map((u) => {
      const ac = activeCert(u.id);
      const acts = [];
      if (isAdmin && u.is_active && u.role === "signer" && !ac) acts.push(h("button", { class: "btn small primary", onclick: () => guarded(async () => { await api("/certificates/issue", { method: "POST", json: { user_id: u.id } }); toast(t("done")); reload(); }) }, t("issue")));
      if (isAdmin && u.is_active && u.id !== S.me.id) acts.push(h("button", { class: "btn small danger", onclick: () => confirm(t("confirm_deactivate")) && guarded(async () => { await api(`/users/${u.id}/deactivate`, { method: "POST" }); reload(); }) }, t("deactivate")));
      return h("tr", {}, h("td", { class: "strong" }, u.full_name), h("td", { class: "mono" }, u.email), h("td", {}, t("role_" + u.role)),
        h("td", {}, badge(u.is_active ? "ok" : "off", u.is_active ? t("u_active") : t("u_inactive"))),
        h("td", {}, u.mfa_enabled ? t("mfa_on") : t("mfa_off")),
        h("td", {}, u.role === "signer" ? (ac ? certBadge(ac) : t("none")) : t("none")),
        isAdmin ? h("td", {}, h("div", { class: "row-actions" }, acts)) : null);
    });
    const head = [t("name"), t("email"), t("role"), t("status"), t("mfa"), t("certificate")]; if (isAdmin) head.push(t("actions"));
    const addForm = isAdmin ? userForm({ title: t("add_user") }, reload) : null;
    return h("div", {}, pageHead(t("users_title"), t("users_sub")), addForm, table(head, rows));
  },

  async certs() {
    const [certs, users] = await Promise.all([api("/certificates"), api("/users")]);
    const isAdmin = S.me.role === "tenant_admin";
    const who = Object.fromEntries(users.map((u) => [u.id, u.full_name]));
    const rows = certs.map((c) => h("tr", {}, h("td", { class: "strong" }, who[c.user_id] || cn(c.subject)),
      h("td", { class: "mono", title: c.serial }, c.serial.slice(0, 14) + "…"), h("td", {}, fmtDate(c.not_after)), h("td", {}, certBadge(c)),
      h("td", {}, h("div", { class: "row-actions" }, h("button", { class: "btn small", onclick: () => showCert(c, who[c.user_id]) }, t("view")),
        isAdmin && certState(c) === "active" ? h("button", { class: "btn small danger", onclick: () => revokeDialog(c) }, t("revoke")) : null))));
    return h("div", {}, pageHead(t("certs_title"), t("certs_sub")), table([t("holder"), t("serial"), t("valid_until"), t("status"), t("actions")], rows), caLinks());
  },

  async mycert() {
    const certs = await api("/certificates/mine");
    const body = certs.length ? certs.map((c) => h("div", { class: "panel" },
      h("div", { style: "display:flex;justify-content:space-between;gap:12px;align-items:center;margin-bottom:14px" }, h("h2", { style: "margin:0" }, cn(c.subject)), certBadge(c)),
      certDetails(c), pemBlock(c))) : [h("div", { class: "panel empty" }, t("no_cert"))];
    return h("div", {}, pageHead(t("mycert_title"), t("mycert_sub")), ...body, caLinks());
  },

  async security() {
    const box = h("div", {});
    const on = S.me.mfa_enabled;
    const paint = () => {
      box.replaceChildren(S.me.mfa_enabled ? badge("ok", t("mfa_enabled_msg")) : h("button", { class: "btn primary", onclick: () => guarded(async () => {
        const r = await api("/auth/mfa/setup", { method: "POST" });
        const code = h("input", { class: "ltr", inputmode: "numeric", maxlength: "6" });
        box.replaceChildren(h("p", { class: "muted" }, t("mfa_secret_hint")), h("div", { class: "secret mono" }, r.secret),
          h("div", { style: "max-width:260px" }, field(t("code"), code)),
          h("button", { class: "btn primary", onclick: () => guarded(async () => { await api("/auth/mfa/confirm", { method: "POST", json: { code: code.value.trim() } }); S.me.mfa_enabled = true; toast(t("mfa_enabled_msg")); paint(); }) }, t("confirm")));
      }) }, t("mfa_enable")));
    };
    paint();
    return h("div", {}, pageHead(t("security_title"), t("security_sub")), h("div", { class: "panel" }, h("h2", {}, t("mfa_title")), h("p", { class: "muted", style: "margin-bottom:14px" }, t("mfa_desc")), box));
  },
};

function table(head, rows) {
  if (!rows.length) return h("div", { class: "table-wrap" }, h("div", { class: "empty" }, t("empty")));
  return h("div", { class: "table-wrap" }, h("table", {}, h("thead", {}, h("tr", {}, head.map((x) => h("th", {}, x)))), h("tbody", {}, rows)));
}
function certDetails(c) {
  return h("dl", { class: "kv" }, h("dt", {}, t("subject")), h("dd", { class: "mono" }, c.subject), h("dt", {}, t("serial")), h("dd", { class: "mono" }, c.serial),
    h("dt", {}, t("valid_from")), h("dd", {}, fmtDate(c.not_before)), h("dt", {}, t("valid_until")), h("dd", {}, fmtDate(c.not_after)));
}
function download(name, text) {
  const a = h("a", { href: URL.createObjectURL(new Blob([text], { type: "application/x-pem-file" })), download: name }); document.body.append(a); a.click(); a.remove();
}
function pemBlock(c) {
  return h("div", {}, h("pre", { class: "pem" }, c.cert_pem), h("div", { style: "margin-top:12px" }, h("button", { class: "btn small", onclick: () => download(`certificate-${c.serial.slice(0, 8)}.pem`, c.cert_pem) }, t("download"))));
}
function showCert(c, name) { modal(name || cn(c.subject), h("div", {}, certDetails(c), pemBlock(c))); }
function revokeDialog(c) {
  const sel = h("select", {}, ["unspecified", "key_compromise", "affiliation_changed", "superseded", "cessation_of_operation"].map((r) => h("option", { value: r }, t("r_" + r))));
  modal(t("revoke_title"), field(t("reason"), sel), (close) => [
    h("button", { class: "btn", onclick: close }, t("cancel")),
    h("button", { class: "btn danger", onclick: () => guarded(async () => { await api(`/certificates/${c.id}/revoke`, { method: "POST", json: { reason: sel.value } }); close(); toast(t("done")); reload(); }) }, t("revoke"))]);
}
function caLinks() {
  return h("div", { class: "links" }, h("a", { href: "/ca/chain.pem", download: "docsign-ca-chain.pem" }, t("ca_chain")), h("a", { href: "/ca/crl.pem", download: "docsign.crl.pem" }, t("ca_crl")));
}

// ---------- boot ----------
function render() { applyLang(); if (!S.me) renderLogin(); else renderShell(); }
async function boot() {
  if (!S.token) return render();
  try { S.me = await api("/users/me"); S.view = null; } catch (_) { S.token = null; sessionStorage.removeItem("tok"); }
  render();
}
boot();
})();
