import os


class Settings:
    database_url: str = os.getenv("DATABASE_URL", "sqlite:///./docsign.db")
    secret_key: str = os.getenv("SECRET_KEY", "dev-only-change-me-use-a-long-random-string")
    token_minutes: int = int(os.getenv("TOKEN_MINUTES", "30"))
    max_failed_logins: int = int(os.getenv("MAX_FAILED_LOGINS", "5"))
    lockout_minutes: int = int(os.getenv("LOCKOUT_MINUTES", "15"))
    bootstrap_admin_email: str = os.getenv("BOOTSTRAP_ADMIN_EMAIL", "admin@example.com")
    bootstrap_admin_password: str = os.getenv("BOOTSTRAP_ADMIN_PASSWORD", "ChangeMe-Now-12345")
    issuer_name: str = "DocSign"
    # Master key protects every private key stored in the database (AES-256-GCM).
    master_key: str = os.getenv("MASTER_KEY", "dev-only-master-key-change-me-before-real-use")
    public_base_url: str = os.getenv("PUBLIC_BASE_URL", "http://localhost:8000")
    cert_valid_days: int = int(os.getenv("CERT_VALID_DAYS", "365"))


settings = Settings()
