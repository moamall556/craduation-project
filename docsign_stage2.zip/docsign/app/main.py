from contextlib import asynccontextmanager
from pathlib import Path

from fastapi import FastAPI
from fastapi.openapi.docs import get_swagger_ui_html
from fastapi.responses import FileResponse, HTMLResponse
from fastapi.staticfiles import StaticFiles
from sqlalchemy import select

from .ca import ensure_ca
from .config import settings
from .database import Base, SessionLocal, engine
from .models import Role, User
from .routers import auth, ca_public, certificates, tenants, users
from .security import hash_password

STATIC = Path(__file__).parent / "static"


@asynccontextmanager
async def lifespan(app: FastAPI):
    Base.metadata.create_all(engine)
    with SessionLocal() as db:
        email = settings.bootstrap_admin_email.lower()
        if not db.scalar(select(User).where(User.email == email)):
            db.add(User(email=email, full_name="Platform Admin", role=Role.platform_admin,
                        password_hash=hash_password(settings.bootstrap_admin_password)))
            db.commit()
        ensure_ca(db)  # creates Root + Issuing CA the first time
    yield


app = FastAPI(title="Secure Multi-Tenant Document Signing Framework", version="0.2.0",
              docs_url=None, lifespan=lifespan)
app.mount("/static", StaticFiles(directory=STATIC), name="static")
for r in (auth.router, tenants.router, users.router, certificates.router, ca_public.router):
    app.include_router(r)


@app.get("/", include_in_schema=False)
def index():
    return FileResponse(STATIC / "index.html")


@app.get("/docs", include_in_schema=False)
def docs():
    page = get_swagger_ui_html(openapi_url="/openapi.json", title="DocSign API").body.decode()
    return HTMLResponse(page.replace("</head>", '<link rel="stylesheet" href="/static/css/swagger.css"></head>'))


@app.get("/health")
def health():
    return {"status": "ok"}
