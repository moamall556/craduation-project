from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy import select
from sqlalchemy.orm import Session

from .. import ca
from ..database import get_db
from ..deps import current_user, require_roles
from ..models import CertStatus, Certificate, Role, Tenant, User, now
from ..schemas import CertIssueIn, CertOut, CertRevokeIn

router = APIRouter(prefix="/certificates", tags=["certificates"])


def _scoped(db: Session, cert_id: str, actor: User) -> Certificate:
    c = db.scalar(select(Certificate).where(Certificate.id == cert_id, Certificate.tenant_id == actor.tenant_id))
    if not c:  # 404 so other tenants' certificate IDs are not revealed
        raise HTTPException(404, "Certificate not found")
    return c


@router.post("/issue", response_model=CertOut, status_code=201)
def issue(data: CertIssueIn, actor: User = Depends(require_roles(Role.tenant_admin)),
          db: Session = Depends(get_db)):
    user = db.scalar(select(User).where(User.id == data.user_id, User.tenant_id == actor.tenant_id))
    if not user:
        raise HTTPException(404, "User not found")
    if user.role != Role.signer or not user.is_active:
        raise HTTPException(400, "Certificates can only be issued to active users with the signer role")
    existing = db.scalars(select(Certificate).where(Certificate.user_id == user.id,
                                                    Certificate.status == CertStatus.active)).all()
    if any(ca.aware(c.not_after) > now() for c in existing):
        raise HTTPException(409, "User already has an active certificate")
    return ca.issue_user_certificate(db, user, db.get(Tenant, actor.tenant_id))


@router.get("", response_model=list[CertOut])
def list_certs(actor: User = Depends(require_roles(Role.tenant_admin, Role.auditor)),
               db: Session = Depends(get_db)):
    return db.scalars(select(Certificate).where(Certificate.tenant_id == actor.tenant_id)
                      .order_by(Certificate.created_at.desc())).all()


@router.get("/mine", response_model=list[CertOut])
def my_certs(actor: User = Depends(current_user), db: Session = Depends(get_db)):
    return db.scalars(select(Certificate).where(Certificate.user_id == actor.id)
                      .order_by(Certificate.created_at.desc())).all()


@router.get("/{cert_id}", response_model=CertOut)
def get_cert(cert_id: str, actor: User = Depends(require_roles(Role.tenant_admin, Role.auditor)),
             db: Session = Depends(get_db)):
    return _scoped(db, cert_id, actor)


@router.post("/{cert_id}/revoke", response_model=CertOut)
def revoke(cert_id: str, data: CertRevokeIn, actor: User = Depends(require_roles(Role.tenant_admin)),
           db: Session = Depends(get_db)):
    c = _scoped(db, cert_id, actor)
    ca.revoke_certificate(db, c, data.reason)
    return c
