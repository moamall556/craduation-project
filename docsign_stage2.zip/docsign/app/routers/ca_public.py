from fastapi import APIRouter, Depends, Response
from sqlalchemy.orm import Session

from .. import ca
from ..database import get_db
from ..models import CaAuthority

router = APIRouter(prefix="/ca", tags=["certificate authority (public)"])


@router.get("/root.pem")
def root_pem(db: Session = Depends(get_db)):
    return Response(db.get(CaAuthority, "root").cert_pem, media_type="application/x-pem-file")


@router.get("/chain.pem")
def chain(db: Session = Depends(get_db)):
    return Response(ca.chain_pem(db), media_type="application/x-pem-file")


@router.get("/crl.pem")
def crl(db: Session = Depends(get_db)):
    return Response(ca.build_crl(db), media_type="application/x-pem-file")
