# Secure Multi-Tenant Document Signing Framework (Stage 2)

Stage 1: tenants, login (Argon2), TOTP MFA, lockout, RBAC, tenant isolation.
Stage 2: internal Certificate Authority (Root -> Issuing CA), per-user certificates with
encrypted private keys (AES-256-GCM), revocation + CRL, and a bilingual (English / Arabic, RTL) web UI.

## Run locally
    python -m venv venv
    venv\Scripts\activate          (Mac/Linux: source venv/bin/activate)
    pip install -r requirements.txt
    python -m uvicorn app.main:app --reload
Open http://localhost:8000      -> web interface (English / Arabic)
Open http://localhost:8000/docs -> interactive API

Default admin: admin@example.com / ChangeMe-Now-12345  (change via .env)
The Root and Issuing CA are created automatically on first start.

## Docker + PostgreSQL
    cp .env.example .env   # edit secrets
    docker compose up --build

## Tests
    python -m pytest -v

## Demo flow
1. Sign in as the platform admin -> create an organization and its admin.
2. Sign in as that admin -> add a user with the Signer role -> "Issue certificate".
3. Sign in as the signer -> "My certificate" shows the certificate.
4. As admin, revoke it -> download the CRL at /ca/crl.pem and see the serial listed.

## Security notes
- Private keys never leave the server and are never returned by any endpoint.
- Each key is encrypted with AES-256-GCM, bound to its certificate id; keep MASTER_KEY secret and backed up.
- Deactivating a user automatically revokes their certificates.
- Prototype only: in production the Root CA key would be offline / in an HSM.
