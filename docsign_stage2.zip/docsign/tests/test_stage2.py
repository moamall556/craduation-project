import pytest
from cryptography import x509
from cryptography.hazmat.primitives import serialization
from cryptography.exceptions import InvalidTag

from app import ca
from app.database import SessionLocal
from app.models import Certificate
from .conftest import auth, login

PW = "StrongPassw0rd!!"


def tok(client, email, pw=PW):
    r = login(client, email, pw)
    assert r.status_code == 200, r.text
    return r.json()["access_token"]


@pytest.fixture(scope="module")
def world(client):
    root = tok(client, "root@example.com", "RootPassword-12345")
    out = {}
    for key, name in (("a", "Stage2 Alpha"), ("b", "Stage2 Beta")):
        t = client.post("/tenants", json={"name": name}, headers=auth(root)).json()
        client.post("/users", headers=auth(root), json={"email": f"s2admin{key}@example.com",
                    "full_name": f"Admin {key}", "password": PW, "role": "tenant_admin", "tenant_id": t["id"]})
        out[key] = tok(client, f"s2admin{key}@example.com")
    sg = client.post("/users", headers=auth(out["a"]), json={"email": "s2signer@example.com",
                     "full_name": "سارة أحمد Sara", "password": PW, "role": "signer"}).json()
    rq = client.post("/users", headers=auth(out["a"]), json={"email": "s2req@example.com",
                     "full_name": "Req Uester", "password": PW, "role": "requester"}).json()
    out["signer_id"], out["req_id"] = sg["id"], rq["id"]
    return out


def test_public_ca_endpoints_and_chain(client):
    chain = client.get("/ca/chain.pem").text
    assert chain.count("BEGIN CERTIFICATE") == 2
    root = x509.load_pem_x509_certificate(client.get("/ca/root.pem").content)
    assert root.subject == root.issuer
    assert "PRIVATE KEY" not in chain
    assert b"BEGIN X509 CRL" in client.get("/ca/crl.pem").content


def test_issue_certificate(client, world):
    r = client.post("/certificates/issue", json={"user_id": world["signer_id"]}, headers=auth(world["a"]))
    assert r.status_code == 201, r.text
    body = r.json()
    world["cert_id"], world["serial"] = body["id"], body["serial"]
    # the private key must never appear in any response
    assert "PRIVATE KEY" not in r.text and "enc_private_key" not in r.text
    cert = x509.load_pem_x509_certificate(body["cert_pem"].encode())
    with SessionLocal() as db:
        assert ca.certificate_state(db, db.get(Certificate, body["id"])) == "valid"
    cn = cert.subject.get_attributes_for_oid(x509.oid.NameOID.COMMON_NAME)[0].value
    assert "Sara" in cn  # Arabic + Latin name accepted
    assert client.post("/certificates/issue", json={"user_id": world["signer_id"]},
                       headers=auth(world["a"])).status_code == 409
    assert client.post("/certificates/issue", json={"user_id": world["req_id"]},
                       headers=auth(world["a"])).status_code == 400


def test_private_key_encrypted_and_bound(client, world):
    with SessionLocal() as db:
        c = db.get(Certificate, world["cert_id"])
        assert "PRIVATE KEY" not in c.enc_private_key
        key = ca.load_user_private_key(c)
        cert = x509.load_pem_x509_certificate(c.cert_pem.encode())
        assert key.public_key().public_numbers() == cert.public_key().public_numbers()
        with pytest.raises(InvalidTag):  # wrong binding data -> decryption refused
            ca.decrypt_bytes(c.enc_private_key, b"cert:other-id")


def test_cross_tenant_isolation_of_certificates(client, world):
    b = auth(world["b"])
    assert client.get(f"/certificates/{world['cert_id']}", headers=b).status_code == 404
    assert client.post(f"/certificates/{world['cert_id']}/revoke", json={}, headers=b).status_code == 404
    assert client.get("/certificates", headers=b).json() == []
    assert client.post("/certificates/issue", json={"user_id": world["signer_id"]}, headers=b).status_code == 404


def test_signer_sees_own_certificate(client, world):
    s = tok(client, "s2signer@example.com")
    mine = client.get("/certificates/mine", headers=auth(s)).json()
    assert [c["id"] for c in mine] == [world["cert_id"]]
    assert client.post("/certificates/issue", json={"user_id": world["signer_id"]},
                       headers=auth(s)).status_code == 403


def test_revocation_and_crl(client, world):
    r = client.post(f"/certificates/{world['cert_id']}/revoke", json={"reason": "key_compromise"},
                    headers=auth(world["a"]))
    assert r.status_code == 200 and r.json()["status"] == "revoked"
    crl = x509.load_pem_x509_crl(client.get("/ca/crl.pem").content)
    assert int(world["serial"], 16) in [rc.serial_number for rc in crl]
    with SessionLocal() as db:
        assert ca.certificate_state(db, db.get(Certificate, world["cert_id"])) == "revoked"
    # a fresh certificate can be issued after revocation
    assert client.post("/certificates/issue", json={"user_id": world["signer_id"]},
                       headers=auth(world["a"])).status_code == 201


def test_deactivating_user_revokes_certificate(client, world):
    certs = client.get("/certificates", headers=auth(world["a"])).json()
    active = [c for c in certs if c["status"] == "active"]
    assert active
    client.post(f"/users/{world['signer_id']}/deactivate", headers=auth(world["a"]))
    certs = client.get("/certificates", headers=auth(world["a"])).json()
    assert all(c["status"] == "revoked" for c in certs)


def test_ui_and_fonts_served(client):
    r = client.get("/")
    assert r.status_code == 200 and "text/html" in r.headers["content-type"]
    assert client.get("/static/fonts/inter-latin-400-normal.woff2").status_code == 200
    assert client.get("/static/fonts/ibm-plex-sans-arabic-arabic-400-normal.woff2").status_code == 200
    assert client.get("/docs").status_code == 200
